<div class="container">

    <h1 class="title">Digital*U</h1>
    <h3 class="subtitle">@ the University of British Columbia</h3>

    <div class="nav">
        <ul class="nav-links">
            <li id="nav-what">
                <a class="nav-link" href="#">What</a>
            </li>
            <li id="nav-how">
                <a class="nav-link" href="#" >Entries</a>
            </li>
            <li id="nav-rules">
                <a class="nav-link" href="#">Rules</a>
            </li>
            <li id="nav-info">
                <a class="nav-link" href="#">FAQ</a>

            </li>
            <li id="nav-register">
                <a class="nav-link" href="#">Register</a>
            </li>

        </ul>
    </div>
